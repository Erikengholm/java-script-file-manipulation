package employeelist;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

public class Employee implements Comparable<Employee>  {
    
    private String Fname;
    private String Lname;
    private String Postion;
    private int Salery;
    private double Tax;
    private int list;
    
    
    public Employee(){
        
       
        this.Fname="";
        this.Lname="";
        this.Postion="";
        this.Salery=0;
        this.Tax=0.0;
        this.list=4;
    }
    
    public Employee(String Fname,String Lname,String Postion,int Salery,double Tax,int list){
    
       
        this.Fname=Fname;
        this.Lname=Lname;
        this.Postion=Postion;       
        this.Salery=Salery;
        this.Tax=Tax;
        this.list=list;
    }

    public double getTax(){
        
        return this.Tax;
    }
    
    public int getSalery(){
        
        return this.Salery;
    }
    
    public String getFname(){
    
        return this.Fname;
    }
    
    public String getLname(){
    
        return this.Lname;
    }
    
    public String getPostion(){
    
        return this.Postion;
    }
    public double getTotalTax(){
        
        return this.Salery-(this.Salery*(this.Tax/100));
    }
    public int getList(){
    
        return this.list;
    
    }
    
    
    public void setFname(String Fname){
    
        this.Fname=Fname;
    }
    
    public void setLname(String Lname){
    
         this.Lname=Lname;
    }
    
    public void setPostion(String postion){
    
        this.Postion=postion;
    }
    
    public void setSalery(int Salery){
        
        this.Salery=Salery;
    }
    
    public void setTax(int tax){
        
        this.Tax=tax;
    
     }
    
    public void setList(int list){
    
        this.list=list;
    
    }
    
    @Override
    //CompareTo är en method som har förmågan att gömföra Strings med varnadra och har en inbyggd alfabet 
    public int compareTo(Employee one){
        
        if(this.list==1){
            return this.getFname().compareTo(one.getFname());
        }
        
        if(this.list==2){
            return this.getLname().compareTo(one.getLname());
        }
        if(this.list==3){
            return this.getPostion().compareTo(one.getPostion());
        }
       
        else{
            return Integer.valueOf(this.getSalery()).compareTo(one.getSalery()); 
        }        
    }
    
    
    @Override
    public String toString(){
       
        Locale defaultLocale = Locale.getDefault();
        Currency currency = Currency.getInstance(defaultLocale);
        NumberFormat nf = NumberFormat.getInstance(defaultLocale);
        nf.setMinimumFractionDigits(2);
        nf.setMaximumFractionDigits(2);
        
        // string.format är en inbyggd class so tillåter mig att kontrolera utskriften mer ,
        //%10s  s betyder att data av vilken typ som hels ska vara och 10 % av hela stringen 
        // -10% och minus betyder att den skapar tom rum från vänstwr istället för höger 
        
        return String.format("%s \t %15s \t %-25s %10s %15s %20s",this.Fname," "+this.Lname,this.Postion,
        nf.format(Salery)+" "+currency.getSymbol(),nf.format(Tax),nf.format(this.getTotalTax())+" "+currency.getSymbol());
               
    }
}
