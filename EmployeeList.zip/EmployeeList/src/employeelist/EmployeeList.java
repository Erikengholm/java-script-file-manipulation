/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employeelist;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class EmployeeList {

    public static void main(String[] args) throws IOException {
        
        Scanner scan= new Scanner(System.in);
        //kallar på en funktion som skriver ut en text 
        sorting();
        //skapar en  ny file om den inte kan hitta en fil via denna väg 
        File f1 =new File("..\\EmployeeList\\src\\employeeList.csv");
        //skapar listan som kommer vara det som skrivs in i filen
        ArrayList<String> datalist = new ArrayList<>();
        //skickar in två variabler in i funktionen csvReader. vägen till filen och sättet jag vill sortera listan
        ArrayList<Employee> employees = (ArrayList<Employee>) csvReader("..\\EmployeeList\\src\\employeeList.csv",scan.nextInt());
        
        datalist.add("First Name\t"+"Last Name\t"+"Postion\t\t\t"+"   Salery\t\t"+"  Tax\t\t"+"salery after tax");
        datalist.add("-----------------------------------------------------------------------------------------------------------------------");
        //sortera hela filen beroende på hur jag vill det
        Collections.sort(employees);
        System.out.println("First Name\t"+"Last Name\t"+"Postion\t"+"Salery\t"+"Tax\t"+"salery after tax");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");
            //går i genom hela employees listan (employee=0 sen ökar med ett för varje varv)
            for(Employee employee : employees){
                //jag gör data till en lång string text som är tostring som jag senare lägger till i datalistan
                String data = employee.toString();
                System.out.println(employee);
                datalist.add(data);
            }
        //tar data till funktionen som ser till att allting skrivs ut i filen
        writefile(f1,datalist);
    }
    
    public static void writefile(File f,ArrayList<String> list)throws IOException{
        FileOutputStream fos = new FileOutputStream(f);
        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(fos))){
            for (int i=0;i < list.size();i++){
                bw.write(list.get(i));
                bw.newLine();
            }
        }
    }
    public static ArrayList<Employee> csvReader(String csvFile, int list) throws IOException {
       
        ArrayList<Employee> Employees = new ArrayList<Employee>();
        System.out.println();
        String line = " ";
        String cvsSplitBy = ";";
        //kallar på en funktion som läser filen mer effektive än filereader 
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))){
            while ((line = br.readLine()) != null){
                    //här sätter jag så att info tar in varje ord som en array tills den mötter en " " eller en ;
                    String[] info = line.split(cvsSplitBy);
                    Employees.add(new Employee(info[0],info[1],info[2],Integer.parseInt(info[3]),Double.parseDouble(info[4]),list));
            }
        } catch (IOException e){
            //om något går fel vissar denna kod vad som inte funkar
            e.printStackTrace();
        }
    //skickar listan av anställda tillbacka till mainen
    return Employees;
    }
   
    public static void sorting(){
        System.out.println("hur vill du sortera listan det defaulta läget är efter förnamn \n"
                + "1 sortera efter förnamn skriv 1 \n"
                + "2 sortera efter efternamn skriv 2 \n"
                + "3 sortera efter postion skriv 3 \n"
                + "4 sortera efter lön skriv 4");
                    
    
    }
   
}